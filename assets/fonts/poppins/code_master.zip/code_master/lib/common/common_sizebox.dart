import 'package:flutter/cupertino.dart';

//................height sizeBox.................//

Widget heightSizeBox(double height) {
  return SizedBox(height: height);
}

//................width sizeBox.................//

Widget widthSizeBox(double width) {
  return SizedBox(width: width);
}
