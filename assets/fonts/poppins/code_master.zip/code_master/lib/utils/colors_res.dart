import 'package:flutter/material.dart';

class ColorRes {
  static const blackColor = Colors.black;
  static const weightColor = Colors.white;
  static const purpleLight =  Color(0XFFBF9EFF);
  static const purpleDark =  Color(0XFF8B4EFF);
  static const purpleLight2 =  Color(0XFFe2d3fe);
}
