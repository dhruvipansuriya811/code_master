import 'package:get/get.dart';

class ProfileScreenController extends GetxController{
  List profileScreenList = [
    "Harsh Savaliya",
    "harshusavaliya8320@gmail.com",
    "8320448899",
    "Male",
  ];





}