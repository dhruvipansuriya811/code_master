import 'package:get/get.dart';

class ExampleScreenController extends GetxController{

}